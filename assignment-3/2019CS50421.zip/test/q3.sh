./waf --run "scratch/Third --conf_num=1"
./waf --run "scratch/Third --conf_num=2"
./waf --run "scratch/Third --conf_num=3"